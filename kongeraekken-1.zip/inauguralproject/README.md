# Inaugural project

The **results** of the project, which follows the structure of the problems in the assignment, can be seen from running [inauguralproject.ipynb](inauguralproject.ipynb).

**Dependencies:** Apart from a standard Anaconda Python 3 installation, the project requires no further packages.