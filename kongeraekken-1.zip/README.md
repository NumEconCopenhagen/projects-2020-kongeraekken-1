# Introduction to Programming and Numerical Analysis - Spring 2020

This is the git hub repository for the team Kongerækken's projects in the course Introduction to Programming and Numerical Analysis offered at the University of Copenhagen.

